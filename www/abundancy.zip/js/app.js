(function(){

    //GLOBAL VARIABLES

    //GLOBAL FUNCTIONS

        /* Menu */
        if($("#menu").length){

            $(".menu-button").on("click", function(){
                $("#menu").toggleClass("open");
            });

            $(".close-button").on("click", function(){
                $("#menu").toggleClass("open");
            });
        }

        /* On Scroll Line Animation */

        if($(".vertical-title").length){

            $(window).scroll(function() { //when window is scrolled

                $(".vertical-title").each(function(){

                    var eTop = $(this).offset().top; //get the offset top of the element
                    var distanceFromTop = eTop - $(window).scrollTop();

                    if(distanceFromTop < 375 && !$(this).hasClass("active")){
                        $(this).addClass("active");
                    }

                });

            });



        }

        /* Parallax */
        if($(".parallax").length){

            var parallax = document.querySelectorAll(".parallax"),
                speed = 0.15;

            window.onscroll = function(){
                [].slice.call(parallax).forEach(function(el,i){

                    var windowYOffset = window.pageYOffset;

                    el.style.backgroundPosition = "0 " + (windowYOffset * speed) + "px";

                });
            };

        }

        /* Text Shuffle */

        if($("#shuffler").length){

            $("#shuffler").slotMachine({
                active : 1,
                delay : 400,
                auto : 1500,
                spins: 2
            });

        }

    //PAGES

        /* Interactive Masthead */
        /* ANTHONY'S STUFF HERE */
        if($("#home").length){

            $("#home-first").css("top", window.innerHeight+"px");
            $("#home-first").css("height", window.innerHeight+"px");

            $("#home-second").css("top", (window.innerHeight*2)+"px");
            $("#home-second").css("height", window.innerHeight+"px");

            $("#container").css("height", window.innerHeight+"px");
            $("body").css("height", window.innerHeight+"px");

            // Loader Load

            function preLoader() {
                var group;
                var container, controls, stats;
                var camera, scene, renderer;

                var r = 800;
                var rHalf = r / 2;

                preLoadInit();
                preLoadAnimate();

                function preLoadInit() {

                    container = document.getElementById( 'loader' );

                    camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 1, 4000 );
                    camera.position.z = 1750;

                    controls = new THREE.OrbitControls( camera, container );

                    scene = new THREE.Scene();
                    scene.background = new THREE.Color( 0x999999 );

                    group = new THREE.Group();
                    scene.add( group );

                    //

                    // Custom basic 2D geometry
                    function IsoscelesTriangleGeometry(base, height) {
                        this.geometry = new THREE.Geometry();
                        this.geometry.vertices.push( new THREE.Vector3(-base, 0, 0) );
                        this.geometry.vertices.push( new THREE.Vector3( base, 0, 0) );
                        this.geometry.vertices.push( new THREE.Vector3( 0, height, 0) );
                        this.geometry.faces.push( new THREE.Face3(0, 1, 2) );
                        this.geometry.computeFaceNormals();
                        this.geometry.computeVertexNormals();
                        return this.geometry;
                    }

                    function EquilateralTriangleGeometry(width) {
                        this.geometry = new THREE.Geometry();
                        this.geometry.vertices.push( new THREE.Vector3(-width, 0, 0) );
                        this.geometry.vertices.push( new THREE.Vector3( width, 0, 0) );
                        this.geometry.vertices.push( new THREE.Vector3( 0, width, 0) );
                        this.geometry.faces.push( new THREE.Face3(0, 1, 2) );
                        this.geometry.computeFaceNormals();
                        this.geometry.computeVertexNormals();
                        return this.geometry;
                    }

                    var ScaleneTriangleGeometry = function(base, sideA, sideB) {
                        this.geometry = new THREE.Geometry();
                        this.geometry.vertices.push( new THREE.Vector3(-base, 0, 0) );
                        this.geometry.vertices.push( new THREE.Vector3( base, 0, 0) );
                        this.geometry.vertices.push( new THREE.Vector3( sideA, sideB, 0) );
                        this.geometry.faces.push( new THREE.Face3(0, 1, 2) );
                        this.geometry.computeFaceNormals();
                        this.geometry.computeVertexNormals();
                        return this.geometry;
                    };

                    // Materials
                    var basicMaterial = new THREE.MeshBasicMaterial( {side: THREE.DoubleSide, wireframe: true, color: 0xc65027, alphaTest:0.1, wireframeLinewidth: 8, transparent: true } );

                    // LEFT
                    var scaleneTriangle1 = new ScaleneTriangleGeometry(200, 1, 220);
                    var triangleA = new THREE.Mesh(scaleneTriangle1, basicMaterial);
                    triangleA.position.set(-100, -200, 0);
                    triangleA.rotation.y = Math.PI / 3;

                    // FRONT
                    var scaleneTriangle2 = new ScaleneTriangleGeometry(200, 100, 300);
                    var triangleB = new THREE.Mesh(scaleneTriangle2, basicMaterial);
                    triangleB.position.set(0, -200, 173);

                    // RIGHT
                    var scaleneTriangle3 = new ScaleneTriangleGeometry(200, -150, 350);
                    var triangleC = new THREE.Mesh(scaleneTriangle3, basicMaterial);
                    triangleC.position.set(100, -200, 0);
                    triangleC.rotation.y = Math.PI / -3;

                    // Add custom objects
                    scene.add(triangleA);
                    scene.add(triangleB);
                    scene.add(triangleC);

                    //

                    renderer = new THREE.CanvasRenderer( { antialias: true, alpha: true } );
                    renderer.setPixelRatio( window.devicePixelRatio );
                    renderer.setSize( window.innerWidth, window.innerHeight );
                    renderer.setClearColor(0x000000, 0);
                    renderer.gammaInput = true;
                    renderer.gammaOutput = true;

                    container.appendChild( renderer.domElement );

                    window.addEventListener( 'resize', onWindowResize, false );

                }

                function preLoadAnimate() {

                    controls.update();
                    TWEEN.update();
                    requestAnimationFrame( preLoadAnimate );
                    preLoadRender();

                }

                function onWindowResize() {

                    camera.aspect = window.innerWidth / window.innerHeight;
                    camera.updateProjectionMatrix();
                    renderer.setSize( window.innerWidth, window.innerHeight );

                }

                function preLoadRender() {

                    var time = Date.now() * 0.001;
                    scene.rotation.y = time * 0.5;
                    renderer.render( scene, camera );

                }

            }
            preLoader();

            // Page Load

            var firstPromise = $.getJSON("http://windev.fq540.com:8001/api/departments");

            firstPromise.done(function(response) {

                console.log(response);

                var countParticles = 0;

                var responseJSON = $.parseJSON(response);
                var departments = [];
                var creativeDept = 0;
                var transparentDept = 0;

                $.each( responseJSON, function( key, val ) {
                    countParticles += (val);
                    /*Creative = Art, Content, Copy, Creative Director, UX Design */
                    /*Transparent = Transparent Account, Transparent Technology */
                    if(key === "Art" || key === "Content" || key === "Copy" || key === "Creative Director" || key === "User Experience Design" || key === "Executive") {
                        creativeDept += val;
                    } else if(key === "Transparent Account" || key === "Transparent Technololgy") {
                        transparentDept += val;
                    } else {
                        console.log(key);
                        departments.push(val);
                    }
                    //console.log(key);
                });

                departments.push(creativeDept);
                departments.push(transparentDept);

                //console.log(departments);

                $("#loader").fadeOut();

                var group;
                var container, controls, stats;
                var particlesData = [];
                var camera, scene, renderer;
                var positions, colors, alphas;
                var particles;
                var pointCloud;
                var linesMesh;

                var uniforms, particlePositions, particleColor, particleSizes;

                var maxParticleCount = 200;
                var particleCount = countParticles;
                //var particleCount = 100;
                //var r = 1.06;
                var r = 1;
                var rHalf = r / 2;

                var effectController = {
                    showDots: true,
                    showLines: true,
                    minDistance: 50,
                    limitConnections: true,
                    maxConnections: 1,
                    particleCount: 0
                };

                var canvas1, context1, texture1, material1,
                    canvas2, context2, texture2, material2,
                    canvas3, context3, texture3, material3,
                    canvas4, context4, texture4, material4,
                    canvas5, context5, texture5, material5;

                var triangleMaterial;
                var triangleGroup = new THREE.Group();

                var projector;
                var curiousMesh;
                var PARTICLE_SIZE = 56;
                var raycaster, intersects;
                var mouse, INTERSECTED;


                //console.log("Particle Count: " + particleCount);

                $("#loader").promise().done(function() {
                    init();
                    animate();
                });

                function init() {

                    container = document.getElementById( 'container' );

                    //

                    camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 1, 4000 );
                    camera.position.z = 1750;

                    controls = new THREE.OrbitControls( camera, container );

                    scene = new THREE.Scene();
                    scene.background = new THREE.Color( 0x4b3024 );

                    hemiLight = new THREE.HemisphereLight( 0xffffff, 0xffffff, 0.6 );
                    hemiLight.color.setHSL( 0.6, 1, 0.6 );
                    hemiLight.groundColor.setHSL( 0.095, 1, 0.75 );
                    hemiLight.position.set( 0, 500, 0 );
                    //scene.add( hemiLight );

                    group = new THREE.Group();
                    scene.add( group );

                    // BOUNDING BOX
                    var helper = new THREE.BoxHelper( new THREE.Mesh( new THREE.BoxGeometry( r*2, r*1.3, r ) ) );
                    helper.material.color.setHex( 0xFFFFFF );
                    helper.material.blending = THREE.AdditiveBlending;
                    helper.material.transparent = true;
                    helper.material.fog = false;
                    //group.add( helper );

                    var tweenHelper = new TWEEN.Tween(helper.scale)
                        .to({ x:800, y: 800, z: 800 }, 2000)
                        .easing(TWEEN.Easing.Sinusoidal.InOut)
                        .onUpdate(function () {
                            helper.scale.set(this.x, this.y, this.z);
                        }).start();

                    // PARTICLES
                    var segments = maxParticleCount * maxParticleCount;

                    positions = new Float32Array( segments * 3 );
                    colors = new Float32Array( segments * 3 );

                    uniforms = {
                        color:     { value: new THREE.Color( 0xFFFFFF ) },
                        texture:   { value: new THREE.TextureLoader().load( "images/icons/ball.png" ) }
                    };

                    var pMaterial = new THREE.ShaderMaterial( {
                        uniforms:       uniforms,
                        vertexShader:   document.getElementById( 'vertexshader' ).textContent,
                        fragmentShader: document.getElementById( 'fragmentshader' ).textContent,
                        blending:       THREE.AdditiveBlending,
                        depthTest:      false,
                        transparent:    true,
                        alphaTest:			0.1,
                        fog: 						false
                    });


                    particles = new THREE.BufferGeometry();
                    particlePositions = new Float32Array( maxParticleCount * 3 );
                    particleColor = new Float32Array( maxParticleCount * 3 );
                    particleSizes = new Float32Array( maxParticleCount );

                    var color = new THREE.Color();

                    var runningTotal;

                    // Joe Added
                    var segmentArray = [];
                    var segmentCount = 0;
                    var hslDegree = 1/360;
                    var pColors = [
                        [ (hslDegree*014), 0.61, 0.42 ],    	// #c65230 // Account Management
                        [ (hslDegree*030), 0.98, 0.60 ],			// #fd9a34 // Analytics (Ardent)
                        [ (hslDegree*060), 0.72, 0.90 ],			// #f8f8d4 // Production
                        [ (hslDegree*000), 0.62, 0.54 ], 			// #d24141 // Project Management
                        [ (hslDegree*079), 0.39, 0.59 ], 			// #a5bf6d // Strategy
                        [ (hslDegree*196), 0.38, 0.52 ], 			// #5599b2 // Technology
                        [ (hslDegree*030), 0.86, 0.39 ], 			// #b8640e // Executives (The Abundancy)
                        [ (hslDegree*042), 0.99, 0.68 ], 			// #fece5c // Creative
                        [ (hslDegree*163), 0.17, 0.72 ] 			// #abc3bc // Media (Transparent)
                    ]

                    // Joe Added
                    for (var x = 1; x <= 9; x++){
                        segmentArray.push(departments[x] + segmentCount);
                        segmentCount += departments[x];
                    }

                    for ( var i = 0; i < maxParticleCount; i++ ) {

                        var x = Math.random() * r - r / 2;
                        var y = Math.random() * r - r / 2;
                        var z = Math.random() * r - r / 2;

                        particlePositions[ i * 3     ] = x;
                        particlePositions[ i * 3 + 1 ] = y;
                        particlePositions[ i * 3 + 2 ] = z;

                        // Joe Added
                        for(var y = pColors.length-1; y >= 0; y--){
                            if (i > segmentArray[pColors.length-1] ){
                                color.setHSL( 1, 1, 1) ;
                            }
                            if (i <= segmentArray[y]){
                                color.setHSL( pColors[y][0], pColors[y][1], pColors[y][2]) ;
                            }
                        }

                        particleColor[ i * 3     ] = color.r;
                        particleColor[ i * 3 + 1 ] = color.g;
                        particleColor[ i * 3 + 2 ] = color.b;

                        particleSizes[ i ] = 56;

                        // add it to the geometry
                        particlesData.push( {
                            velocity: new THREE.Vector3( -1 + Math.random() * 2, -1 + Math.random() * 2,  -1 + Math.random() * 2 ),
                            numConnections: 0,
                            name: i
                        } );

                        if ( i <= (particleCount*.3333) ) {
                            r = r+2;
                        } else if (i > particleCount*.3333 && i <= particleCount*.6666){
                            r = r+3;
                        } else {
                            r = r+4.6;
                        }

                        rHalf = r / 2;

                    }

                    particles.setDrawRange( 0, particleCount );
                    particles.addAttribute( 'position', new THREE.BufferAttribute( particlePositions, 3 ).setDynamic( true ) );
                    particles.addAttribute( 'customColor', new THREE.BufferAttribute( particleColor, 3 ) );
                    particles.addAttribute( 'size', new THREE.BufferAttribute( particleSizes, 1 ) );


                    // create the particle system
                    pointCloud = new THREE.Points( particles, pMaterial );
                    group.add( pointCloud );

                    //

                    // STATIC PARTICLE AND TEXT
                    var staticParticleGeometry = new THREE.Geometry();
                    staticParticleGeometry.vertices.push(
                        new THREE.Vector3( 400, -400, 0 )
                    );

                    var staticParticleMaterial = new THREE.PointsMaterial({
                        color: 				0x45d6f8,
                        size:					48,
                        map: 					new THREE.TextureLoader().load( "images/icons/ball.png" ),
                        transparent:	true
                    });

                    var staticParticle = new THREE.Points(staticParticleGeometry, staticParticleMaterial);
                    scene.add( staticParticle );

                    curiousCanvas = document.createElement('canvas');
                    curiousCanvas.needsUpdate = true;
                    curiousCanvas.width = 400;

                    curiousContext = curiousCanvas.getContext('2d');
                    curiousContext.font = "Bold 20px Futura";
                    curiousContext.fillStyle = "rgba(255,155,32,1)";
                    var ctext = "CURIOUS?".split("").join(String.fromCharCode(8201));
                    curiousContext.fillText(ctext, 0, 80);

                    curiousTexture = new THREE.Texture( curiousCanvas )
                    curiousTexture.needsUpdate = true;
                    curiousTexture.minFilter = THREE.LinearFilter

                    curiousMaterial = new THREE.MeshBasicMaterial( { map: curiousTexture, color: 0xFFFFFF, transparent: true, opacity: 1, side: THREE.DoubleSide, alphaTest: 0.5 });
                    curiousMaterial.needsUpdate = true;

                    curiousMesh = new THREE.Mesh( new THREE.PlaneGeometry(curiousCanvas.width, curiousCanvas.height), curiousMaterial );
                    curiousMesh.position.set(622,-403,0);
                    curiousMesh.needsUpdate = true;
                    curiousMesh.name = "Curious";

                    curiousMesh.callback = function() { showStats(); }
                    scene.add( curiousMesh );

                    //

                    var geometry = new THREE.BufferGeometry();

                    geometry.addAttribute( 'position', new THREE.BufferAttribute( positions, 3 ).setDynamic( true ) );
                    geometry.addAttribute( 'color', new THREE.BufferAttribute( colors, 3 ).setDynamic( true ) );

                    geometry.computeBoundingSphere();
                    geometry.setDrawRange( 0, 0 );

                    //

                    var material = new THREE.LineBasicMaterial( {
                        color: 0x666666,
                        vertexColors: THREE.VertexColors,
                        blending: THREE.AdditiveBlending,
                        transparent: true
                    } );

                    linesMesh = new THREE.LineSegments( geometry, material );
                    group.add( linesMesh );

                    //

                    setTimeout(function(){
                        var interval = setInterval(function () {

                            effectController.maxConnections = effectController.maxConnections + 1;
                            effectController.minDistance = effectController.minDistance + 4;

                            //console.log(effectController.maxConnections);

                            if (effectController.maxConnections >= 50) {
                                clearInterval(interval);
                            }
                        }, 200);
                    }, 1000);

                    //

                    projector = new THREE.Projector();

                    renderer = new THREE.WebGLRenderer( { antialias: true, alpha: true } );
                    renderer.setPixelRatio( window.devicePixelRatio );
                    renderer.setSize( window.innerWidth, window.innerHeight );
                    renderer.setClearColor(0x4b3024, 1);

                    renderer.gammaInput = false;
                    renderer.gammaOutput = false;

                    container.appendChild( renderer.domElement );

                    //

                    raycaster = new THREE.Raycaster();
                    mouse = new THREE.Vector2();
                    raycaster.params.Points.threshold = 10;

                    //

                    document.addEventListener( 'mousemove', onDocumentMouseMove, false );
                    document.addEventListener('mouseup', stopDrag, false);
                    document.addEventListener('mousedown', startDrag, false);
                    document.addEventListener('click', onDocumentMouseDown, false );
                    window.addEventListener( 'resize', onWindowResize, false );

                }


                function animate() {

                    controls.update();
                    TWEEN.update();

                    var vertexpos = 0;
                    var colorpos = 0;
                    var numConnected = 0;

                    for ( var i = 0; i < particleCount; i++ )
                        particlesData[ i ].numConnections = 0;

                    for ( var i = 0; i < particleCount; i++ ) {

                        // get the particle
                        var particleData = particlesData[i];

                        particlePositions[ i * 3     ] += particleData.velocity.x;
                        particlePositions[ i * 3 + 1 ] += particleData.velocity.y;
                        particlePositions[ i * 3 + 2 ] += particleData.velocity.z;

                        if ( particlePositions[ i * 3 + 1 ] < -(rHalf*1.3) || particlePositions[ i * 3 + 1 ] > (rHalf*1.3) )
                            particleData.velocity.y = -particleData.velocity.y;

                        if ( particlePositions[ i * 3 ] < -(rHalf*2) || particlePositions[ i * 3 ] > (rHalf*2) )
                            particleData.velocity.x = -particleData.velocity.x;

                        if ( particlePositions[ i * 3 + 2 ] < -rHalf || particlePositions[ i * 3 + 2 ] > rHalf )
                            particleData.velocity.z = -particleData.velocity.z;

                        if ( effectController.limitConnections && particleData.numConnections >= effectController.maxConnections )
                            continue;

                        // Check collision
                        for ( var j = i + 1; j < particleCount; j++ ) {

                            var particleDataB = particlesData[ j ];
                            if ( effectController.limitConnections && particleDataB.numConnections >= effectController.maxConnections )
                                continue;

                            var dx = (particlePositions[ i * 3     ] - particlePositions[ j * 3     ])*2;
                            var dy = particlePositions[ i * 3 + 1 ] - particlePositions[ j * 3 + 1 ];
                            var dz = particlePositions[ i * 3 + 2 ] - particlePositions[ j * 3 + 2 ];
                            var dist = Math.sqrt( dx * dx + dy * dy + dz * dz );

                            if ( dist < effectController.minDistance ) {

                                particleData.numConnections++;
                                particleDataB.numConnections++;

                                var alpha = 1.0 - dist / effectController.minDistance;

                                positions[ vertexpos++ ] = particlePositions[ i * 3     ];
                                positions[ vertexpos++ ] = particlePositions[ i * 3 + 1 ];
                                positions[ vertexpos++ ] = particlePositions[ i * 3 + 2 ];

                                positions[ vertexpos++ ] = particlePositions[ j * 3     ];
                                positions[ vertexpos++ ] = particlePositions[ j * 3 + 1 ];
                                positions[ vertexpos++ ] = particlePositions[ j * 3 + 2 ];

                                colors[ colorpos++ ] = alpha;
                                colors[ colorpos++ ] = alpha;
                                colors[ colorpos++ ] = alpha;

                                colors[ colorpos++ ] = alpha;
                                colors[ colorpos++ ] = alpha;
                                colors[ colorpos++ ] = alpha;

                                numConnected++;
                            }
                        }
                    }

                    linesMesh.geometry.setDrawRange( 0, numConnected * 2 );
                    linesMesh.geometry.attributes.position.needsUpdate = true;
                    linesMesh.geometry.attributes.color.needsUpdate = true;

                    pointCloud.geometry.attributes.position.needsUpdate = true;

                    requestAnimationFrame( animate );


                    //stats.update();
                    render();

                }

                function showStats() {

                    var from = {
                        x: camera.position.x,
                        y: camera.position.y,
                        z: camera.position.z
                    };

                    var to = {
                        x: camera.position.x,
                        y: camera.position.y,
                        z: 200
                    };

                    var tween = new TWEEN.Tween(from)
                        .to(to, 1000)
                        .easing(TWEEN.Easing.Sinusoidal.InOut)
                        .onUpdate(function () {
                            camera.position.set(this.x, this.y, this.z);
                            camera.lookAt(new THREE.Vector3(0, 0, 0));
                        })
                        .onComplete(function () {
                            camera.lookAt(new THREE.Vector3(0, 0, 0));
                            $("#home-overlay").css("display", "flex").hide().fadeIn(1000);

                        }).start();

                    var from = {
                        x: triangleGroup.rotation.x,
                        y: triangleGroup.rotation.y,
                        z: triangleGroup.rotation.z
                    };

                    var to = {
                        x: 0,
                        y: 0,
                        z: 0
                    };

                    var tween = new TWEEN.Tween(from)
                        .to(to, 1000)
                        .easing(TWEEN.Easing.Sinusoidal.InOut)
                        .onUpdate(function () {
                            triangleGroup.rotation.set(this.x, this.y, this.z);
                        })
                        .onComplete(function () {
                        }).start();

                }

                function onDocumentMouseMove( event ) {
                    event.preventDefault();
                    mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
                    mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;

                }

                function onDocumentMouseDown( event ) {
                    event.preventDefault();
                    mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
                    mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
                    raycaster.setFromCamera( mouse, camera );
                    var curiousIntersect = raycaster.intersectObject( curiousMesh );
                    if ( curiousIntersect.length > 0 ) {
                        curiousIntersect[0].object.callback();
                    }
                }

                function startDrag(event) {

                    $("#scroll-down").fadeOut();

                    var from = {
                        x: triangleGroup.rotation.x,
                        y: triangleGroup.rotation.y,
                        z: triangleGroup.rotation.z
                    };

                    var to = {
                        x: 0,
                        y: 0,
                        z: 0
                    };

                    var tween = new TWEEN.Tween(from)
                        .to(to, 1000)
                        .easing(TWEEN.Easing.Sinusoidal.InOut)
                        .onUpdate(function () {
                            triangleGroup.rotation.set(this.x, this.y, this.z);
                        })
                        .onComplete(function () {
                        }).start();
                }

                function stopDrag(event) {

                    var from = {
                        x: triangleGroup.rotation.x,
                        y: triangleGroup.rotation.y,
                        z: triangleGroup.rotation.z
                    };

                    var to = {
                        x: 0.35,
                        y: 0.05,
                        z: -0.01
                    };

                    var tween = new TWEEN.Tween(from)
                        .to(to, 1000)
                        .easing(TWEEN.Easing.Sinusoidal.InOut)
                        .onUpdate(function () {
                            triangleGroup.rotation.set(this.x, this.y, this.z);
                            $("#home-overlay").fadeOut(1000);
                        })
                        .onComplete(function () {
                            $("#home-overlay").css("display","none");

                        }).start();


                    var from = {
                        x: camera.position.x,
                        y: camera.position.y,
                        z: camera.position.z
                    };

                    var to = {
                        x: 0,
                        y: 0,
                        z: 1750
                    };
                    var tween = new TWEEN.Tween(from)
                        .to(to, 1000)
                        .easing(TWEEN.Easing.Sinusoidal.InOut)
                        .onUpdate(function () {
                            camera.position.set(this.x, this.y, this.z);
                            camera.lookAt(new THREE.Vector3(0, 0, 0));
                        })
                        .onComplete(function () {
                            $("#scroll-down").fadeIn();
                            camera.lookAt(new THREE.Vector3(0, 0, 0));
                            $("#stats").html("Curious?");

                        }).start();

                }

                function onWindowResize() {
                    camera.aspect = window.innerWidth / window.innerHeight;
                    camera.updateProjectionMatrix();
                    renderer.setSize( window.innerWidth, window.innerHeight );
                }

                //

                function render() {

                    setTimeout(function(){

                        r = 800;

                        var geometry = pointCloud.geometry;
                        var attributes = geometry.attributes;

                        raycaster.setFromCamera( mouse, camera );
                        intersects = raycaster.intersectObject( pointCloud );

                        if ( intersects.length > 0 ) {
                            if ( INTERSECTED != intersects[ 0 ].index ) {
                                console.log("HIT!");
                                attributes.size.array[ INTERSECTED ] = PARTICLE_SIZE;
                                INTERSECTED = intersects[ 0 ].index;
                                attributes.size.array[ INTERSECTED ] = PARTICLE_SIZE * 1.75;
                                attributes.size.needsUpdate = true;
                            }
                        } else if ( INTERSECTED !== null ) {
                            attributes.size.array[ INTERSECTED ] = PARTICLE_SIZE;
                            attributes.size.needsUpdate = true;
                            INTERSECTED = null;
                        }
                    }, 2000);

                    renderer.render( scene, camera );

                }

            });
        }

        /* Home */
        if($("#home").length){

            console.log("The Abundancy / Home");

            var modal = $(".modal");

            // Background flying triangles
            $(".triangle").each(function(){
                var triangle = $(this),
                    randomDecimal = generateDecimal();

                TweenMax.set(triangle,{ top: generateStringPercentage(), left: generateStringPercentage(), scale:randomDecimal} );

                var bezier_path = [{ top: generateStringPercentage(), left: generateStringPercentage() }, { top: generateStringPercentage(), left: generateStringPercentage() }, { top: generateStringPercentage(), left: generateStringPercentage() }];

                TweenMax.to(triangle, 50, { bezier: { type: 'thru', values: bezier_path,curviness: 1, autoRotate: true}, ease: Power1.easeInOut, yoyo: true, repeat:-1});

            });

            // Leadership profile squares
            $(".leadership li").on("click", function(){

                var name = $(this).find(".modal-name").text(),
                    title = $(this).find(".modal-title").text(),
                    iAmA = $(this).find(".modal-i_am_a").text(),
                    bio = $(this).find(".modal-bio").text();

                modal.find(".name").text(name);
                modal.find(".title").text(title);
                modal.find(".i_am_a").text(iAmA);
                modal.find(".text").text(bio);
                modal.find("img").attr("src", "images/home/leadership/gif/" + $(this).attr("data-person") + ".gif");

                $(".modal-contain").toggleClass("open");
                modal.toggleClass("animated fadeInUp");

                $("html").addClass("noscroll");
                
            });

            // Modal close button
            $(".modal-button").on("click", function(){
                $(".modal-contain").toggleClass("open");
                $(".modal").toggleClass("animated fadeInUp");
                $("html").removeClass("noscroll");
            });

            // Animate Get Chosen text

            var chosenSmall = $("#get-chosen-small"),
                chosenLarge = $("#get-chosen-large");

            var totalDistanceNeededToTravel = chosenLarge.offset().top - chosenSmall.offset().top;
            var totalLeftDistanceNeededToTravel = chosenSmall.offset().left - chosenLarge.offset().left;

            function animateGetChosen() {

                if ($(window).width() > 680) {

                    var distanceFromTop = $(".parallax .small").offset().top - $(window).scrollTop();

                    var totalDistanceTraveled = totalDistanceNeededToTravel - (chosenLarge.offset().top - chosenSmall.offset().top),
                        percentageTraveled = totalDistanceTraveled / totalDistanceNeededToTravel;

                    if(distanceFromTop < 350 && !chosenSmall.hasClass("complete")){

                        var distanceTopDifference = (350 - distanceFromTop);

                        var fontSize = 18 + ((60 - 18) * percentageTraveled);

                        if (distanceFromTop < -40) {

                            chosenSmall.css({
                                color: '#F8F9D2',
                                top: totalDistanceNeededToTravel + 14,
                                left: -(totalLeftDistanceNeededToTravel),
                                fontSize: "60px",
                                lineHeight: "60px",
                                transition: "all 0.4s ease"
                            });

                            chosenSmall.find("span").css({
                                color: '#C55227',
                                fontSize: "60px",
                                lineHeight: "60px"
                            });

                            chosenSmall.addClass("complete");

                            setTimeout(function(){
                                chosenSmall.hide();
                                chosenLarge.css({
                                    opacity: 1
                                });
                                $(".btn.home.parallax-btn").addClass("animated fadeIn");
                            }, 500);

                            setTimeout(function(){
                                $(".clients ul").addClass("animated fadeIn");
                            }, 1000);

                        }

                        else {

                            var leftOffset = -(totalLeftDistanceNeededToTravel * percentageTraveled);

                            chosenSmall.css({
                                top: distanceTopDifference,
                                left: leftOffset,
                                fontSize: fontSize + "px",
                                lineHeight: fontSize + "px"
                            });

                        }

                    } else if (distanceFromTop > 350 && !chosenSmall.hasClass("complete")) {

                        chosenSmall.css({
                            color: '#DDDDDC',
                            top: 0,
                            left: 0,
                            fontSize: 18 + "px",
                            lineHeight: 18 + "px"
                        });

                    }

                }

            }

            function generateStringPercentage() {
                var min = 0,
                    max = 100,
                    percentage = Math.floor(Math.random() * (max - min + 1) + min).toString() + "%";
                return percentage;
            }

            function generateDecimal(){
                return (Math.random()).toFixed(2);
            }

            function initHome(){
                animateGetChosen();
            }

            // window.scroll()
            $(window).scroll(function() {
                animateGetChosen();
            });

            // window.resize()
            $(window).resize(function() {
                animateGetChosen();
            });


            initHome();

        }

        /* Our Approach */
        if($("#approach").length){
            console.log("The Abundancy / Our Approach");

            // Graph SVG Iconography

            layer8();
            setInterval(layer8(), 6000);

            function layer8(){
                drawLine("#Layer_8 #line-8-1",0,2,"ease-in-out");
                drawLine("#Layer_8 #line-8-2",1900,0.5,"linear");
                drawLine("#Layer_8 #line-8-3",1900,0.5,"linear");
            }

            // ID OF LINE, DELAY OF START, LENGTH TO COMPLETE, EASING
            function drawLine(pathToDraw,delay,duration,easing){
                var path = document.querySelector(pathToDraw);
                var length = path.getTotalLength();
                path.style.transition = path.style.WebkitTransition = "none";
                path.style.strokeDasharray = length + " " + length;
                path.style.strokeDashoffset = length;
                path.getBoundingClientRect();
                path.style.transition = path.style.WebkitTransition = "stroke-dashoffset " + duration + "s " + easing;
                setTimeout(function(){
                    path.style.strokeDashoffset = "0";
                },delay);

            }

        }

        /* Our Work */
        if($("#cases").length){
            console.log("The Abundancy / Our Work");
        }

        /* Our Culture */
        if($("#culture").length){
            console.log("The Abundancy / Our Culture");

            var token = '390074368.1439f97.94f68308db0542b1bd4fe81f4abac769',
                num_photos = 15;

            $.ajax({
                url: 'https://api.instagram.com/v1/users/self/media/recent',
                dataType: 'jsonp',
                type: 'GET',
                data: {access_token: token, count: num_photos},
                success: function(data){
                    console.log(data);

                    var imageCount = 0;

                    for( num in data.data ){
                        if (imageCount >= 8){
                            break;
                        }
                        if (data.data[num].type != 'video'){
                            $('.instagram-feed').append('<div class="box"><img src="'+data.data[num].images.standard_resolution.url+'"><a class="insta-overlay" href="'+ data.data[num].link +'" target="_blank"><div class="insta-heart">'+ data.data[num].likes.count + '</div><div class="insta-comments">'+ data.data[num].comments.count + '</div></a></div>');
                            imageCount++;
                        }
                        console.log(imageCount);
                    }

                },
                error: function(data){
                    console.log(data);
                }
            });

            // Graph SVG Iconography

            setTimeout(function(){
                $("#bolt-lines").removeClass("bolt-before").addClass("bolt-after");
            },3000);

        }

        /* Contact + Careers */
        if($("#contact").length){

            console.log("The Abundancy / Contact + Careers");

            $( ".input-field" ).focus(function() {
                if(!$(this).hasClass("input-filled")){
                    $(this).parent().addClass("input-filled");
                }
            });

            $( ".input-field" ).blur(function() {

                if($(this).val() === '') {
                    $(this).parent().removeClass("input-filled");
                }

            });

            $('.dropdown').fancySelect();

            $("#contact-us-form").submit(function(e){
                e.preventDefault();

                var name = $("#input-name input").val(),
                    mail = $("#input-email input").val(),
                    subject = $("input-subject").val(),
                    iama = $("input-iama").val();

                alert("Name: " + name + " Email: " + mail + " Subject: " + subject + " I am a: " + iama);

            });

            // Recruiter box
            $.ajax({
                url: 'https://jsapi.recruiterbox.com/v1/openings?client_name=theabundancy',
                contentType: 'application/json',
                success: function(response) {

                    for(var x = 0; x < response.objects.length; x++){

                        var position = response.objects[x];
                        var formatted = '<li>' + '<div class="position">' + position.title + '<br />' +
                                        position.location.city + ', ' + position.location.state + ', ' + position.location.country +
                                        '</div>' + '<div class="type">' + position.position_type.replace(/[_-]/g, " ") + '</div>' +
                                        '<a href="'+ position.hosted_url +'" class="read-more" target="_blank">READ MORE</a>' +
                                        '</li>';
                        $(".openings").append(formatted);
                    }

                }
            });

        }


})();